const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const DB_PATH = path.join(__dirname, 'db.json');

app.use(cors());
app.use(bodyParser.json());

function readDB() {
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// Obtener todos los productos
app.get('/productos', (req, res) => {
  const db = readDB();
  res.json(db.productos);
});

// Obtener carrito por usuario (con detalles de producto)
app.get('/carrito/:usuario', (req, res) => {
  const db = readDB();
  const carrito = db.carritos.find(c => c.usuario === req.params.usuario);
  if (!carrito) return res.json([]);
  // Enriquecer con detalles del producto
  const items = carrito.items.map(item => {
    const producto = db.productos.find(p => p.id === item.productoId);
    return {
      ...item,
      producto: producto || null
    };
  });
  res.json(items);
});

// Agregar producto al carrito (o aumentar cantidad)
app.post('/carrito', (req, res) => {
  const { usuario, productoId, cantidad = 1 } = req.body;
  const db = readDB();

  let carrito = db.carritos.find(c => c.usuario === usuario);
  if (!carrito) {
    carrito = { usuario, items: [] };
    db.carritos.push(carrito);
  }

  const item = carrito.items.find(i => i.productoId === productoId);
  if (item) {
    item.cantidad += cantidad;
  } else {
    carrito.items.push({ productoId, cantidad });
  }

  writeDB(db);
  res.json({ message: 'Producto agregado al carrito' });
});

// Eliminar producto del carrito
app.delete('/carrito', (req, res) => {
  const { usuario, productoId } = req.body;
  const db = readDB();
  const carrito = db.carritos.find(c => c.usuario === usuario);

  if (!carrito) return res.status(404).json({ error: 'Carrito no encontrado' });

  carrito.items = carrito.items.filter(item => item.productoId !== productoId);
  writeDB(db);
  res.json({ message: 'Producto eliminado del carrito' });
});

// Simular pago (vaciar carrito)
app.post('/carrito/pagar', (req, res) => {
  const { usuario } = req.body;
  const db = readDB();
  const carrito = db.carritos.find(c => c.usuario === usuario);

  if (!carrito) return res.status(404).json({ error: 'Carrito no encontrado' });

  carrito.items = [];
  writeDB(db);
  res.json({ message: 'Compra realizada con éxito' });
});

// Login (valida correo, usuario y contraseña)
app.post('/login', (req, res) => {
  const { correo, usuario, contrasena } = req.body;
  const db = readDB();
  const user = db.usuarios.find(
    u => u.correo === correo && u.usuario === usuario && u.contrasena === contrasena
  );
  if (user) {
    res.json({ success: true, rol: user.rol, usuario: user.usuario });
  } else {
    res.status(401).json({ success: false, message: 'Datos incorrectos' });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});