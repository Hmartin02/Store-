document.getElementById("login-form").addEventListener("submit", async function (e) {
  e.preventDefault();
  const correo = document.getElementById("correo").value;
  const usuario = document.getElementById("usuario").value;
  const contrasena = document.getElementById("contrasena").value;

  document.getElementById("login-error").textContent = "";

  const res = await fetch('http://localhost:3000/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ correo, usuario, contrasena })
  });

  if (res.ok) {
    const data = await res.json();
    localStorage.setItem('rol', data.rol);
    localStorage.setItem('usuario', data.usuario);

    document.getElementById("login-section").style.display = "none";
    document.querySelector("main").style.display = "block";
    document.getElementById("login-error").textContent = "";

    if (data.rol === "admin") {
      document.getElementById("login-error").textContent = "Bienvenido administrador";
    } else {
      document.getElementById("login-error").textContent = "Bienvenido cliente";
    }
  } else {
    document.getElementById("login-error").textContent = "Datos incorrectos. Intenta de nuevo.";
  }
});