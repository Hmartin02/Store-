document.addEventListener('DOMContentLoaded', async () => {
  const usuario = localStorage.getItem('usuario');
  if (!usuario) {
    alert('Debes iniciar sesión primero');
    window.location.href = 'login.html';
    return;
  }

  const productosContainer = document.getElementById('productos');
  const carritoContainer = document.getElementById('carrito');
  const totalContainer = document.getElementById('total');

  let carrito = [];

  // Cargar productos desde la API
  try {
    const res = await fetch('http://localhost:3000/productos');
    const productos = await res.json();

    productos.forEach(prod => {
      const div = document.createElement('div');
      div.classList.add('producto');
      div.innerHTML = `
        <h3>${prod.nombre}</h3>
        <p>Precio: $${prod.precio}</p>
        <label for="talla">Talla:</label>
        <select id="talla">
          <option value="S">S</option>
          <option value="M">M</option>
          <option value="L">L</option>
        </select>
        <label for="color">Color:</label>
        <select id="color">
          <option value="rojo">Rojo</option>
          <option value="verde">Verde</option>
          <option value="azul">Azul</option>
        </select>
        <button data-id="${prod.id}">Agregar al carrito</button>
      `;
      productosContainer.appendChild(div);
    });

    productosContainer.addEventListener('click', async (e) => {
      if (e.target.tagName === 'BUTTON') {
        const productoId = parseInt(e.target.getAttribute('data-id'));
        const productoDiv = e.target.closest('.producto');
        const nombre = productoDiv.querySelector('h3').textContent;
        const precio = parseFloat(productoDiv.querySelector('p').textContent.replace('Precio: $', ''));

        agregarAlCarrito(e.target, nombre, precio);

        const res = await fetch('http://localhost:3000/carrito', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ usuario, productoId, nombre, precio })
        });
        const data = await res.json();
        actualizarCarrito(data.carrito);
      }
    });

  } catch (err) {
    console.error('Error cargando productos:', err);
  }

  // Cargar carrito existente
  async function cargarCarrito() {
    const res = await fetch(`http://localhost:3000/carrito/${usuario}`);
    const data = await res.json();
    actualizarCarrito(data);
  }

  function agregarAlCarrito(boton, nombre, precio) {
    // Busca el contenedor del producto
    const productoDiv = boton.closest('.producto');
    // Busca los selects de talla y color dentro del producto
    const talla = productoDiv.querySelector('select[id^="talla"]').value;
    const color = productoDiv.querySelector('select[id^="color"]').value;

    // Agrega el producto al carrito
    carrito.push({ nombre, precio, talla, color });
    actualizarCarrito();
  }

  function actualizarCarrito(items) {
    carrito = items;
    carritoContainer.innerHTML = '';
    let total = 0;
    carrito.forEach(item => {
      const li = document.createElement('li');
      li.textContent = `${item.nombre} - $${item.precio} (Talla: ${item.talla}, Color: ${item.color})`;
      carritoContainer.appendChild(li);
      total += item.precio;
    });
    totalContainer.textContent = `Total: $${total}`;
  }

  function eliminarDelCarrito(index) {
    carrito.splice(index, 1);
    actualizarCarrito();
  }

  document.getElementById('checkout-btn').addEventListener('click', async () => {
    const res = await fetch('http://localhost:3000/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usuario })
    });
    const data = await res.json();
    alert(data.mensaje + '\nTotal: $' + data.total);
    carritoContainer.innerHTML = '';
    totalContainer.textContent = 'Total: $0';
  });

  cargarCarrito();
});

document.getElementById("login-form").addEventListener("submit", function (e) {
  e.preventDefault();
  const usuario = document.getElementById("usuario").value;
  const contrasena = document.getElementById("contrasena").value;

  if (usuario === "admin" && contrasena === "1234") {
    document.getElementById("login-section").style.display = "none";
    document.querySelector("main").style.display = "block";
  } else {
    alert("Usuario o contraseña incorrectos");
  }
});

const traducciones = {
  es: {
    login: "Iniciar Sesión",
    email: "Correo electrónico",
    username: "Nombre de usuario",
    password: "Contraseña",
    enter: "Entrar",
    productos: "Productos",
    carrito: "Carrito",
    total: "Total"
    // ...agrega más textos según necesites
  },
  en: {
    login: "Login",
    email: "Email",
    username: "Username",
    password: "Password",
    enter: "Enter",
    productos: "Products",
    carrito: "Cart",
    total: "Total"
    // ...agrega más textos según necesites
  }
};

document.getElementById("selector-idioma").addEventListener("change", function() {
  const lang = this.value;
  document.getElementById("login-title").textContent = traducciones[lang].login;
  document.querySelector("label[for='correo']").textContent = traducciones[lang].email;
  document.querySelector("label[for='usuario']").textContent = traducciones[lang].username;
  document.querySelector("label[for='contrasena']").textContent = traducciones[lang].password;
  document.querySelector("#login-form button[type='submit']").textContent = traducciones[lang].enter;
  document.getElementById("productos-title").textContent = traducciones[lang].productos;
  document.getElementById("carrito-title").textContent = traducciones[lang].carrito;
  document.querySelector("strong").textContent = traducciones[lang].total + ":";
  // ...actualiza más textos según necesites
});

document.getElementById("selector-tema").addEventListener("change", function() {
  if (this.value === "oscuro") {
    document.body.classList.add("tema-oscuro");
  } else {
    document.body.classList.remove("tema-oscuro");
  }
});