let carrito = [];

function agregarAlCarrito(nombre, precio, idTalla, idColor) {
  const talla = document.getElementById(idTalla).value;
  const color = document.getElementById(idColor).value;
  carrito.push({ nombre, precio, talla, color });
  actualizarCarrito();
}

function actualizarCarrito() {
  const lista = document.getElementById("lista-carrito");
  const totalSpan = document.getElementById("total");
  lista.innerHTML = "";
  let total = 0;
  carrito.forEach((item, index) => {
    total += item.precio;
    const li = document.createElement("li");
    li.textContent = `${item.nombre} - Talla: ${item.talla}, Color: ${item.color} - $${item.precio}`;
    const botonEliminar = document.createElement("button");
    botonEliminar.textContent = "Eliminar";
    botonEliminar.onclick = () => eliminarDelCarrito(index);
    li.appendChild(botonEliminar);
    lista.appendChild(li);
  });
  totalSpan.textContent = total;
}

function eliminarDelCarrito(index) {
  carrito.splice(index, 1);
  actualizarCarrito();
}

// --- Carrito alternativo conectado al backend (API) ---

const usuario = 'cliente1'; // Simulación simple
const API = 'http://localhost:3000';

// Cargar productos para la vista alternativa
async function cargarProductos() {
  const res = await fetch(`${API}/productos`);
  const productos = await res.json();
  const contenedor = document.getElementById('productos');
  if (!contenedor) return;
  contenedor.innerHTML = '';
  productos.forEach(p => {
    const div = document.createElement('div');
    div.className = 'producto-alt';
    div.innerHTML = `
      <strong>${p.nombre}</strong><br>
      Precio: $${p.precio}<br>
      <button onclick="agregarAlCarritoAPI(${p.id})">Agregar al carrito</button>
    `;
    contenedor.appendChild(div);
  });
}

async function agregarAlCarritoAPI(productoId) {
  await fetch(`${API}/carrito`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usuario, productoId, cantidad: 1 })
  });
  mostrarCarritoAPI();
}

async function mostrarCarritoAPI() {
  const res = await fetch(`${API}/carrito/${usuario}`);
  const items = await res.json();
  const carritoDiv = document.getElementById('carrito');
  if (!carritoDiv) return;
  carritoDiv.innerHTML = '';
  let total = 0;
  items.forEach(item => {
    const nombre = item.producto ? item.producto.nombre : `ID: ${item.productoId}`;
    const precio = item.producto ? item.producto.precio : 0;
    total += precio * item.cantidad;
    const div = document.createElement('div');
    div.innerHTML = `
      ${nombre} - $${precio} | Cantidad: ${item.cantidad}
      <button onclick="eliminarDelCarritoAPI(${item.productoId})">Eliminar</button>
    `;
    carritoDiv.appendChild(div);
  });
  carritoDiv.innerHTML += `<p><strong>Total:</strong> $${total}</p>`;
}

async function eliminarDelCarritoAPI(productoId) {
  await fetch(`${API}/carrito`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usuario, productoId })
  });
  mostrarCarritoAPI();
}

async function pagarCarrito() {
  await fetch(`${API}/carrito/pagar`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usuario })
  });
  alert('¡Compra realizada!');
  mostrarCarritoAPI();
}

// Inicializar la vista alternativa si existen los elementos
if (document.getElementById('productos') && document.getElementById('carrito')) {
  cargarProductos();
  mostrarCarritoAPI();
}
